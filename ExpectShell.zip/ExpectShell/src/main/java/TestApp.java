import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;
import java.util.concurrent.TimeUnit;
import net.sf.expectit.Expect;
import net.sf.expectit.ExpectBuilder;
import net.sf.expectit.ExpectIOException;

import static net.sf.expectit.matcher.Matchers.contains;
import static net.sf.expectit.matcher.Matchers.eof;
import static net.sf.expectit.matcher.Matchers.regexp;

public class TestApp {

    public static void main(String [] args) {

        try{

            ProcessBuilder pb = new ProcessBuilder("E:\\Sandbox\\ExpectShell\\src\\main\\resources\\sample_interact.bat");
            Process process = pb.start();

            long timeout = 5000;
            final Expect expect = new ExpectBuilder()
                    .withTimeout(timeout, TimeUnit.SECONDS)
                    .withOutput(process.getOutputStream())
                    .withInputs(process.getInputStream(), process.getErrorStream())
                    .withEchoOutput(System.out)
                    .withEchoInput(System.err)
                    //        .withInputFilters(removeColors(), removeNonPrintable())
                    .withExceptionOnFailure()
                    .build();

            Scanner reader = new Scanner(System.in);


            expect.interact()
                    .when(contains("continue")).then(r -> expect.sendLine(reader.next()))
                    .when(contains("again")).then(r -> expect.sendLine(reader.next()))
                    .when(contains("x2")).then((r) -> { expect.sendLine(reader.next()); })
                    .when(contains("x3")).then((r) -> { expect.sendLine(reader.next()); })
            .until(contains("exit"));
            System.out.println("DONE!");

//            String total = expect.expect(regexp("Do you want to continue?\\s*")).group(0);
//            System.out.println("");
//            System.out.println("Quest: " + total);
//
//            // try-with-resources is omitted for simplicity
//            Scanner reader = new Scanner(System.in);
//
//            // Reading data using readLine
//            String input = reader.next();
//            expect.sendLine(input);
//            //expect.sendLine("\n");
//
//
//            String second = expect.expect(regexp("Do you want it again?\\s*")).group(0);
//            System.out.println("2nd Quest: " + second);
//
//            input = reader.next();
//            expect.sendLine(input);
//
//            String third = expect.expect(regexp("Do you want it too x2?\\s*")).group(0);
//            System.out.println("3rd Quest: " + third);
//
//            input = reader.next();
//            expect.sendLine(input);
            // capture the total

//            // capture file list
//            String list = expect.expect(regexp("\n$")).getBefore();
//            // print the result
//            System.out.println("List: " + list);

            //expect.sendLine("exit");
            // expect the process to finish
            //expect.expect(eof());
            // finally is omitted
            process.waitFor();
            expect.close();

        } catch (ExpectIOException e) {
            System.out.println("seems exited by user due to timeout expect.");

            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
        finally {

//            try {
//                if (expect != null)
//                    expect.close();
//            }
//            catch(IOException ex) {
//                System.out.println("Unable to close Expect resource.");
//                System.out.println(ex.toString());
//            }
        }
    }
}
